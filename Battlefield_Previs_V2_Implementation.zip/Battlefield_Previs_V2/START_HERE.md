# 一镜到底战场白膜预演 · V2 实现稿

打开 delivery_v2/battlefield_v2.blend；观看 delivery_v2/battlefield_v2_previs.mp4。

视频约 190 秒、30 FPS、480×270。主脚本 battlefield_v2.py 与 validate_scene.py 一起使用，一键构建及检查。路线、曲线、碰撞报告、画面索引和操作说明都在 delivery_v2/。

请先阅读 delivery_v2/验收记录.md：当前不是最终验收通过版，Blender 5.2.x 未实测；风吹硝烟与阳光变化、水下效果和关键表演仍有未通过项。实机验证版本是 Blender 4.3.2。

reference_original/ 完整保留上传包内的 12 个原文件，内容校验一致。未覆盖原版。
